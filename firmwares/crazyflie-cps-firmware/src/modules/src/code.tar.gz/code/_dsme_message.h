#ifndef __MASSAGE_H__
#define __MASSAGE_H__

#include <stdint.h>

// A Message has 2 parts: 1. header
//                        2. data
#define MESSAGE_LENGTH_IN_BYTE 120 // The total length of every SPI Message
#define DATA_LENGTH_IN_BYTE 118

/**************************** Define Data Types ****************************/
#define META_DATA 0

typedef struct __attribute__((packed))
{
    uint8_t data_type;
    uint8_t id;
} header_t;

typedef struct __attribute__((packed))
{
    header_t header;
    uint8_t data[DATA_LENGTH_IN_BYTE];
} message_t;

#endif