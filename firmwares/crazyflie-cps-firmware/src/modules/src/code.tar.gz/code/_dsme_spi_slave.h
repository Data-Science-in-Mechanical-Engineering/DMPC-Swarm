#ifndef __DSME_SPI_SLAVE_H__
#define __DSME_SPI_SLAVE_H__

#include <stdbool.h>

void spiSlaveTaskInit();
bool spiSlaveTaskTest();

#endif